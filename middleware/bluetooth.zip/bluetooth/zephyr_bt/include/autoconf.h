#ifndef AUTOCONF_H
#define AUTOCONF_H
#include <zephyr/autoconf.h>
#endif