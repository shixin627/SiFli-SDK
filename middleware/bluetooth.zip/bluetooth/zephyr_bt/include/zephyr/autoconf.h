#ifndef ZEPHYR_AUTOCONF_H
#define ZEPHYR_AUTOCONF_H

#define CONFIG_LITTLE_ENDIAN 1
#include "rtt4zephyr.h"

#endif