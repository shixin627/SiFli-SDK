# SiFli Bluetooth patches

## Overview

This is official Sifli bluetooth controller CPU(LCPU) images and patches release.
Each subfolder contain the image and patches for a SiFli SF32LB soc serial, and also
for installation help function implement. 

Relevant documentation:
- https://wiki.sifli.com/
- https://docs.sifli.com/projects/sdk/latest/sf32lb52x/index.html
