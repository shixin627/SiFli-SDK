/*
 * SPDX-FileCopyrightText: 2024-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef __BF0_BLE_CSCPC_H
#define __BF0_BLE_CSCPC_H

#include "bf0_ble_common.h"

enum cscp_meas_flags
{
    /// Wheel Revolution Data Present
    BLE_CSCP_MEAS_WHEEL_REV_DATA_PRESENT    = 0x01,
    /// Crank Revolution Data Present
    BLE_CSCP_MEAS_CRANK_REV_DATA_PRESENT    = 0x02,

    /// All present
    BLE_CSCP_MEAS_ALL_PRESENT               = 0x03,
};

enum ble_cscpc_event
{
    //CSC Measurement Notify RSP see @ble_csc_meas_value_ind
    BLE_CSCPC_CSC_MEASUREMENT_NOTIFY = BLE_CSCPC_TYPE,
    //CSC Feature Read RSP see @ble_csc_feat_value_ind
    BLE_CSCPC_READ_CSC_FEATURE_RSP,
    //Sensor Loaction Read RSP see @ble_sensor_loc_value_ind
    BLE_CSCPC_READ_SENSOR_LOCATION_RSP,
    //SC Control Point Write RSP
    BLE_CSCPC_WEITE_CONTROL_POINT_RSP,
    //SC Control Point Indicate RSP @cscpc_ctnl_pt_rsp
    BLE_CSCPC_CONTROL_POINT_INDICATE,
};

enum cscp_sc_ctnl_pt_op_code
{
    /// Reserved value
    CSCP_CTNL_PT_OP_RESERVED        = 0,

    /// Set Cumulative Value
    CSCP_CTNL_PT_OP_SET_CUMUL_VAL,
    /// Start Sensor Calibration
    CSCP_CTNL_PT_OP_START_CALIB,
    /// Update Sensor Location
    CSCP_CTNL_PT_OP_UPD_LOC,
    /// Request Supported Sensor Locations
    CSCP_CTNL_PT_OP_REQ_SUPP_LOC,

    /// Response Code
    CSCP_CTNL_PT_RSP_CODE           = 16,
};

enum cscp_ctnl_pt_resp_val
{
    /// Reserved value
    CSCP_CTNL_PT_RESP_RESERVED      = 0,

    /// Success
    CSCP_CTNL_PT_RESP_SUCCESS,
    /// Operation Code Not Supported
    CSCP_CTNL_PT_RESP_NOT_SUPP,
    /// Invalid Parameter
    CSCP_CTNL_PT_RESP_INV_PARAM,
    /// Operation Failed
    CSCP_CTNL_PT_RESP_FAILED,
};

enum cscp_sensor_loc
{
    /// Other (0)
    CSCP_LOC_OTHER          = 0,
    /// Front Wheel (4)
    CSCP_LOC_FRONT_WHEEL    = 4,
    /// Left Crank (5)
    CSCP_LOC_LEFT_CRANK,
    /// Right Crank (6)
    CSCP_LOC_RIGHT_CRANK,
    /// Left Pedal (7)
    CSCP_LOC_LEFT_PEDAL,
    /// Right Pedal (8)
    CSCP_LOC_RIGHT_PEDAL,
    /// Rear Dropout (9)
    CSCP_LOC_REAR_DROPOUT,
    /// Chainstay (10)
    CSCP_LOC_CHAINSTAY,
    /// Front Hub (11)
    CSCP_LOC_FRONT_HUB,
    /// Rear Wheel (12)
    CSCP_LOC_REAR_WHEEL,
    /// Rear Hub (13)
    CSCP_LOC_REAR_HUB,

    CSCP_LOC_MAX,
};

typedef struct
{
    /// Operation code
    uint8_t operation;
    /// Status
    uint8_t status;
} ble_cscpc_cmp_evt;

struct cscp_csc_meas
{
    /// Flags
    uint8_t flags;
    /// Cumulative Crank Revolution
    uint16_t cumul_crank_rev;
    /// Last Crank Event Time
    uint16_t last_crank_evt_time;
    /// Last Wheel Event Time
    uint16_t last_wheel_evt_time;
    /// Cumulative Wheel Revolution
    uint32_t cumul_wheel_rev;
};

typedef struct
{
    uint8_t att_code;
    struct cscp_csc_meas csc_meas;
} ble_csc_meas_value_ind;

typedef struct
{
    uint8_t att_code;
    uint16_t sensor_feat;
} ble_csc_feat_value_ind;

typedef struct
{
    uint8_t att_code;
    uint8_t sensor_loc;
} ble_sensor_loc_value_ind;

typedef struct
{
    uint8_t att_code;
    uint16_t ntf_cfg;
} ble_sc_ctnl_pt_value_ind;

struct cscp_sc_ctnl_pt_req
{
    /// Operation Code
    uint8_t op_code;
    /// Value
    union cscp_sc_ctnl_pt_req_val
    {
        /// Sensor Location
        uint8_t sensor_loc;
        /// Cumulative value
        uint32_t cumul_val;
    } value;
};

struct cscpc_ctnl_pt_cfg_req
{
    /// Operation Code
    uint8_t operation;
    /// SC Control Point Request
    struct cscp_sc_ctnl_pt_req sc_ctnl_pt;
};


struct cscp_sc_ctnl_pt_rsp
{
    /// Requested Operation Code
    uint8_t req_op_code;
    /// Response Value
    uint8_t resp_value;
    /// List of supported locations
    uint16_t supp_loc;
};


struct cscpc_ctnl_pt_rsp
{
    /// SC Control Point Response
    struct cscp_sc_ctnl_pt_rsp ctnl_pt_rsp;
};

void ble_cscpc_init(uint8_t enable);
//csc feature read req
int8_t ble_cscpc_read_csc_feature(uint8_t conn_idx);
//sensor location read req
int8_t ble_cscpc_read_sensor_location(uint8_t conn_idx);

int8_t ble_cscpc_enable(uint8_t conn_idx);
//sc control point characteristic extended properties descriptors read req
int8_t ble_cscpc_read_sc_ct_pt_cepd(uint8_t conn_idx);

/**
  ******************************************************************************
  csc measurement notify on-off
  flag==1    notify on
  flag==0    notify off
  ******************************************************************************
*/
void ble_csc_meas_ntf_enable(uint16_t flag);

/**
  ******************************************************************************
  sc control point indicate on-off
  flag==2    indicate on
  flag==0    indicate off
  ******************************************************************************
*/
void ble_sc_ct_pt_ind_enable(uint16_t flag);
#endif //__BF0_BLE_CSCPC_H