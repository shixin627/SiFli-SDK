/*
 * SPDX-FileCopyrightText: 2019-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _BF0_SIBLES_CONSOLE_H
#define _BF0_SIBLES_CONSOLE_H

int rt_ble_serial_dev_register(const char *name);

#endif // _BF0_SIBLES_CONSOLE_H

