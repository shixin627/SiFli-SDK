import * as lv from "lv"
import { app } from "lvapp"
import * as lv_enums from "/lv_enums.js"
import { idximg } from "/idximg.js"
import { label } from "/label.js"

class wf5 extends app {
    constructor() {
        super(1);		// Watch APP set 1 as parameter
    }

    refresh() {
        var cur_time = new Date();
        // print(cur_time.getHours());
        // print(cur_time.getMinutes());
        this.time_ul.select(cur_time.getHours() / 10);
        this.time_ur.select(cur_time.getHours() % 10);
        this.time_bl.select(cur_time.getMinutes() / 10);
        this.time_br.select(cur_time.getMinutes() % 10);
        var weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        var month = cur_time.getMonth() + 1;
        var day = cur_time.getDate();
        var weekday = weekdays[cur_time.getDay()];
        this.date_label.set_text(weekday + " " + ((month <= 9) ? "0" : "") + month + "/" + ((day <= 9) ? "0" : "") + day);
    }
    start() {
        // Upper left
        this.time_ul = new idximg(this.root());
        this.time_ul.set_pos(110, 53);
        this.time_ul.prefix("/JW_wf5/dig_1_");

        // Upper right
        this.time_ur = new idximg(this.root());
        this.time_ur.set_pos(250, 53);
        this.time_ur.prefix("/JW_wf5/dig_1_");

        // Bottom left
        this.time_bl = new idximg(this.root());
        this.time_bl.set_pos(110, 245);
        this.time_bl.prefix("/JW_wf5/dig_2_");

        // Bottom right
        this.time_br = new idximg(this.root());
        this.time_br.set_pos(250, 245);
        this.time_br.prefix("/JW_wf5/dig_2_");

        this.date_label = new label(this.root());
        this.date_label.align(lv_enums.ALIGN_IN_BOTTOM_MID, 0, -15);
        this.date_label.set_local_font(lv_enums.FONT_TITLE, lv_enums.LV_COLOR_WHITE);
        this.refresh();
    }

    resume() {
        this.task(
            function () {
                this.refresh();
            }
            , 1000
        );
    }
}
globalThis.wf5 = wf5;
